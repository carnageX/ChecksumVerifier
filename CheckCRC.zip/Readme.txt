Andrew Koupparis, http://www34.brinkster.com/dizzyk/index.html

A few things about the CRC32 Calculator

The program calculates the 32-bit Cyclic Redundency Check (CRC32) of a given file.

It comes at two versions right now, both for windows (tested with Win98). The command-line version is quite small and delicate, you can just type "crc32" to see the instructions. The CheckCRC is the "windows" version, and it is capable of adding a "crc32" feature in the right-click menu.

Both programs are created with Delphi 6. They are new versions, completely rewritten and don't use third party routines.

The Windows based program: CheckCRC

Extract the file, then run CheckCRC.exe. You will also find install.txt and this file.

The program will add a selection (CRC32) to the popup menu when you right-click any file. To remove this go to Control Panel -> Add/Remove Programs -> CRC32 Calculator. Please note that you must delete the file manually to completely remove the program from your system.

A window will come up with a button (Select File). Click the button, select a file and its crc32 will be displayed.

When you use the right-click menu command the same window will come up, only now the CRC32 of the selected file will be already calculated.

Note that ARC CRC and 16-bit XModem CRC is no longer supported.

